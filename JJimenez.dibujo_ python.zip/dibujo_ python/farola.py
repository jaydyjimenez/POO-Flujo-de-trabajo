#REALIZADO POR: JAYDY NAOMI JIMENEZ MANZANAREZ
#PROFESOR: JOSE ARMANDO GUTIERREZ
#MATERIA: PROGRAMACIÓN ORIENTADA A OBJETOS  GRUPO: 05IMPRMA
#FECHA: MARZO 01, 2025


from clases import Figura, Rectangulo
from foco import Foco
from luz import Luz

class Farola(Figura):
    def __init__(self, x, y):
        super().__init__()
        self.posicion.coordX = x
        self.posicion.coordY = y
        
        self.poste = Rectangulo()
        self.poste.dimension.base = 5
        self.poste.dimension.altura = 70
        self.poste.color = (50, 50, 50)
        
        self.brazo = Rectangulo()
        self.brazo.dimension.base = 35
        self.brazo.dimension.altura = 5
        self.brazo.color = (50, 50, 50)
        
        self.foco = Foco(35, 5)
        self.haz_luz = Luz()

    def dibujar(self):
        ox = self.posicion.coordX
        oy = self.posicion.coordY
        self.haz_luz.dibujar(offsetX=ox, offsetY=oy)
        self.poste.dibujar(offsetX=ox, offsetY=oy)
        self.brazo.dibujar(offsetX=ox, offsetY=oy)
        self.foco.dibujar(offsetX=ox, offsetY=oy)