#REALIZADO POR: JAYDY NAOMI JIMENEZ MANZANAREZ
#PROFESOR: JOSE ARMANDO GUTIERREZ
#MATERIA: PROGRAMACIÓN ORIENTADA A OBJETOS  GRUPO: 05IMPRMA
#FECHA: MARZO 01, 2025


from clases import Elipse

class Foco(Elipse):
    def __init__(self, x=0, y=0):
        super().__init__(posicion=None, dimension=None, color=(255, 255, 200))
        self.posicion.coordX = x
        self.posicion.coordY = y
        self.dimension.base = 16 
        self.dimension.altura = 10