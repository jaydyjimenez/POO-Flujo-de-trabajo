#REALIZADO POR: JAYDY NAOMI JIMENEZ MANZANAREZ
#PROFESOR: JOSE ARMANDO GUTIERREZ
#MATERIA: PROGRAMACIÓN ORIENTADA A OBJETOS  GRUPO: 05IMPRMA
#FECHA: MARZO 01, 2025


from clases import Figura
from p5 import triangle, no_stroke, fill

class Luz(Figura):
    def dibujar(self, x=None, y=None, offsetX=0, offsetY=0):
        fill(255, 255, 0, 50) 
        no_stroke()
        triangle(offsetX + 35, offsetY, 
                 offsetX - 5, offsetY + 70, 
                 offsetX + 75, offsetY + 70)