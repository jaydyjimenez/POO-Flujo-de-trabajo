#REALIZADO POR: JAYDY NAOMI JIMENEZ MANZANAREZ
#PROFESOR: JOSE ARMANDO GUTIERREZ
#MATERIA: PROGRAMACIÓN ORIENTADA A OBJETOS  GRUPO: 05IMPRMA
#FECHA: MARZO 01, 2025


from clases import Rectangulo

class Piso(Rectangulo):
    def __init__(self, ancho=800, alto=500):
        super().__init__() 
        
        self.color = (50, 50, 50)
        self.posicion.coordX = 0
        self.posicion.coordY = 350
        self.dimension.base = ancho
        self.dimension.altura = 150
        self.borde.grosor = 0