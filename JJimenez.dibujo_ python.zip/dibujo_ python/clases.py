#REALIZADO POR: JAYDY NAOMI JIMENEZ MANZANAREZ
#PROFESOR: JOSE ARMANDO GUTIERREZ
#MATERIA: PROGRAMACIÓN ORIENTADA A OBJETOS  GRUPO: 05IMPRMA
#FECHA: MARZO 01, 2025


from p5 import *

class Borde:
    def __init__(self, color=(0, 0, 0), grosor=2):
        self.color = color
        self.grosor = grosor

class Posicion:
    def __init__(self, coordX=0, coordY=0):
        self.coordX = coordX
        self.coordY = coordY

class Dimension:
    def __init__(self, base=100, altura=100):
        self.base = base
        self.altura = altura

class Figura:
    def __init__(self, borde=None, posicion=None, dimension=None, color=(255, 255, 255), speed=5, escala=1):
        self.borde = borde if borde is not None else Borde()
        self.posicion = posicion if posicion is not None else Posicion()
        self.dimension = dimension if dimension is not None else Dimension()
        self.color = color
        self.speed = speed
        self.escala = escala

    def dibujar(self, x=None, y=None, offsetX=0, offsetY=0):
        pass

class Rectangulo(Figura):
    def dibujar(self, x=None, y=None, offsetX=0, offsetY=0):
        bx = x if x is not None else self.posicion.coordX
        by = y if y is not None else self.posicion.coordY
        
        origenX = bx + offsetX
        origenY = by + offsetY
        
        ancho = self.dimension.base * self.escala
        alto = self.dimension.altura * self.escala
        
        stroke(*self.borde.color)
        stroke_weight(self.borde.grosor)
        fill(*self.color)
        rect(origenX, origenY, ancho, alto)

class Elipse(Figura):
    def dibujar(self, x=None, y=None, offsetX=0, offsetY=0):
        bx = x if x is not None else self.posicion.coordX
        by = y if y is not None else self.posicion.coordY
        
        origenX = bx + offsetX
        origenY = by + offsetY
        
        ancho = self.dimension.base * self.escala
        alto = self.dimension.altura * self.escala
        
        stroke(*self.borde.color)
        stroke_weight(self.borde.grosor)
        fill(*self.color)
        ellipse(origenX, origenY, ancho, alto)