#REALIZADO POR: JAYDY NAOMI JIMENEZ MANZANAREZ
#PROFESOR: JOSE ARMANDO GUTIERREZ
#MATERIA: PROGRAMACIÓN ORIENTADA A OBJETOS  GRUPO: 05IMPRMA
#FECHA: MARZO 01, 2025


from clases import Rectangulo
from ventana import Ventana 

class Casa(Rectangulo):
    def __init__(self, x, y):
        super().__init__()
        self.posicion.coordX = x
        self.posicion.coordY = y
        self.dimension.base = 75   
        self.dimension.altura = 100 
        self.color = (200, 200, 200) 
        
        self.techo = Rectangulo()
        self.techo.dimension.base = 85
        self.techo.dimension.altura = 10
        self.techo.color = (100, 100, 100)
        
        self.v_izquierda = Ventana(x=8, y=25)
        self.v_derecha = Ventana(x=42, y=25)

    def dibujar(self, x=None, y=None, offsetX=0, offsetY=0):
        super().dibujar(offsetX=offsetX, offsetY=offsetY)
        
        self.techo.dibujar(x=self.posicion.coordX - 5, 
                           y=self.posicion.coordY - 10, 
                           offsetX=offsetX, offsetY=offsetY)
        
        self.v_izquierda.dibujar(offsetX=offsetX + self.posicion.coordX, 
                                 offsetY=offsetY + self.posicion.coordY)
        self.v_derecha.dibujar(offsetX=offsetX + self.posicion.coordX, 
                               offsetY=offsetY + self.posicion.coordY)