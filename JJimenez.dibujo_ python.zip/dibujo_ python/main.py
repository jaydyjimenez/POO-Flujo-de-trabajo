#REALIZADO POR: JAYDY NAOMI JIMENEZ MANZANAREZ
#PROFESOR: JOSE ARMANDO GUTIERREZ
#MATERIA: PROGRAMACIÓN ORIENTADA A OBJETOS  GRUPO: 05IMPRMA
#FECHA: MARZO 01, 2025

from p5 import *
from farola import Farola
from luna import Luna
from piso import Piso
from casa import Casa 

farola = None
luna = None
suelo = None
casa = None

def setup():
    size(500, 400)
    global farola, luna, suelo, casa
    suelo = Piso(500,500)
    casa = Casa(100, 250) 
    farola = Farola(300, 280)
    luna = Luna(400, 150)

def draw():
    background(20, 25, 50)
    
    luna.dibujar()
    suelo.dibujar()
    casa.dibujar()  
    farola.dibujar()

run()