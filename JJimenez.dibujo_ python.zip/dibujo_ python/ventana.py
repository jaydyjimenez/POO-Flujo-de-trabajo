#REALIZADO POR: JAYDY NAOMI JIMENEZ MANZANAREZ
#PROFESOR: JOSE ARMANDO GUTIERREZ
#MATERIA: PROGRAMACIÓN ORIENTADA A OBJETOS  GRUPO: 05IMPRMA
#FECHA: MARZO 01, 2025


from clases import Rectangulo
from p5 import line, stroke, stroke_weight

class Ventana(Rectangulo):
    def __init__(self, x=0, y=0, w=25, h=40):
        super().__init__()
        self.posicion.coordX = x
        self.posicion.coordY = y
        self.dimension.base = w
        self.dimension.altura = h
        self.color = (135, 206, 235) 
        self.borde.grosor = 2

    def dibujar(self, x=None, y=None, offsetX=0, offsetY=0):
  
        super().dibujar(x, y, offsetX, offsetY)
        
        bx = x if x is not None else self.posicion.coordX
        by = y if y is not None else self.posicion.coordY
        vx = bx + offsetX
        vy = by + offsetY
        
        stroke(255) 
        stroke_weight(1)
        line(vx + self.dimension.base/2, vy, 
             vx + self.dimension.base/2, vy + self.dimension.altura)
        line(vx, vy + self.dimension.base/2, 
             vx + self.dimension.base, vy + self.dimension.base/2)