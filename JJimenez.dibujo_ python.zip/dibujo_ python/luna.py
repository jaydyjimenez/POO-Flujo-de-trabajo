#REALIZADO POR: JAYDY NAOMI JIMENEZ MANZANAREZ
#PROFESOR: JOSE ARMANDO GUTIERREZ
#MATERIA: PROGRAMACIÓN ORIENTADA A OBJETOS  GRUPO: 05IMPRMA
#FECHA: MARZO 01, 2025


from clases import Elipse

class Luna(Elipse):
    def __init__(self, x, y):
        super().__init__(color=(240, 240, 240))
        self.posicion.coordX = x
        self.posicion.coordY = y
        self.dimension.base = 35 
        self.dimension.altura = 35